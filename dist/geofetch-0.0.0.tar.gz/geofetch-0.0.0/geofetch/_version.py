""" Provide modules access to central, single point of version definition. """
__version__ = "0.1-dev"
